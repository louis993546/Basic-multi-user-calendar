package hkust.cse.calendar.gui;

public class DuplicateApp implements Runnable{
	private int a;
	
	
	public DuplicateApp(int a){
		this.a = a;
	}
	
    @Override
	public void run() {
		
	}
}
