package hkust.cse.calendar.gui;

public class NewUserDialog {

}
