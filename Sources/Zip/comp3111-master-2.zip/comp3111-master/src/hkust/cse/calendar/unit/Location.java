package hkust.cse.calendar.unit;

public class Location {
	private String _name;
	
	public Location(String name){
		_name = name;
	}
	
	public String getName(){
		return _name;
	}
	
	public void setName(String name){
		_name = name;
	}
	
	public String toString() {
		return _name;
	}

}
