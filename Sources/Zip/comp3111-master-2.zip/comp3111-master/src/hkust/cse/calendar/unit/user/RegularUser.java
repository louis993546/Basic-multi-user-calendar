package hkust.cse.calendar.unit.user;

import java.io.Serializable;


public class RegularUser extends User implements Serializable {

	public RegularUser(String id, String pass) {
		super(id, pass);
		// TODO Auto-generated constructor stub
	}

}
