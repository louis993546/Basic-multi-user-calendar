package hkust.cse.calendar.notification;

public enum NotificationService {

	Alert,
	Sms,
	Email
}
