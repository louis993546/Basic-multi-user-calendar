package hkust.cse.calendar.notification;

public interface INotification {
	public void Send();
}
